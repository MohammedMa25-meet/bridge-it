import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Alert, ImageBackground } from 'react-native';
import { Button } from 'react-native-paper';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const UserTypeScreen = ({ route, navigation }) => {
  const { userId } = route.params;
  const [selectedType, setSelectedType] = useState(null);
  const [loading, setLoading] = useState(false);

  const handleContinue = async () => {
    if (!selectedType) {
      Alert.alert('Error', 'Please select an account type');
      return;
    }

    setLoading(true);

    try {
      // Update user document with the selected role
      await updateDoc(doc(db, 'users', userId), {
        role: selectedType,
      });

      // Navigate to questionnaire screen with user type
      navigation.navigate('Questionnaire', {
        userId,
        userType: selectedType
      });
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      style={styles.backgroundImage}
      source={{uri: 'https://images.unsplash.com/photo-1600880292203-757bb62b4baf?q=80&w=2940'}}
    >
      <View style={styles.overlay}>
        <View style={styles.container}>
          <View style={styles.header}>
            <Text style={styles.logoText}>Bridge-iT</Text>
            <Text style={styles.progressText}>Step 2 of 3</Text>
          </View>

          <View style={styles.content}>
            <Text style={styles.title}>I am a...</Text>
            <Text style={styles.subtitle}>Select your account type</Text>

            <View style={styles.optionsContainer}>
              <TouchableOpacity
                style={[
                  styles.optionCard,
                  selectedType === 'jobseeker' && styles.selectedCard
                ]}
                onPress={() => setSelectedType('jobseeker')}
              >
                <View style={styles.iconPlaceholder}>
                  <Text style={styles.iconText}>👨‍💻</Text>
                </View>
                <Text style={styles.optionTitle}>Job Seeker</Text>
                <Text style={styles.optionDescription}>
                  I'm looking for job opportunities in the tech field
                </Text>
                <View style={styles.features}>
                  <Text style={styles.featureItem}>• Browse employer profiles</Text>
                  <Text style={styles.featureItem}>• Connect with hiring companies</Text>
                  <Text style={styles.featureItem}>• Highlight your skills and experience</Text>
                </View>
              </TouchableOpacity>

              <TouchableOpacity
                style={[
                  styles.optionCard,
                  selectedType === 'employer' && styles.selectedCard
                ]}
                onPress={() => setSelectedType('employer')}
              >
                <View style={styles.iconPlaceholder}>
                  <Text style={styles.iconText}>🏢</Text>
                </View>
                <Text style={styles.optionTitle}>Employer</Text>
                <Text style={styles.optionDescription}>
                  I'm looking to hire talented tech professionals
                </Text>
                <View style={styles.features}>
                  <Text style={styles.featureItem}>• Browse candidate profiles</Text>
                  <Text style={styles.featureItem}>• Message qualified professionals</Text>
                  <Text style={styles.featureItem}>• Find the perfect match for your team</Text>
                </View>
              </TouchableOpacity>
            </View>

            <Button
              mode="contained"
              onPress={handleContinue}
              style={styles.button}
              loading={loading}
              disabled={loading || !selectedType}
              buttonColor={Colors.primaryGreen}
              textColor={Colors.white}
            >
              Continue to Questionnaire
            </Button>

            <View style={styles.stepIndicator}>
              <View style={styles.stepDot}></View>
              <View style={[styles.stepDot, styles.activeDot]}></View>
              <View style={styles.stepDot}></View>
            </View>
          </View>
        </View>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(187, 190, 160, 0.85)', // primaryLight with opacity
  },
  container: {
    flex: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    paddingTop: 20,
    marginBottom: 20,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  progressText: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginTop: 5,
  },
  content: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontSize: 32,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 10,
    color: Colors.primaryDark,
  },
  subtitle: {
    fontSize: 18,
    textAlign: 'center',
    marginBottom: 30,
    color: Colors.primaryDark,
  },
  optionsContainer: {
    marginBottom: 30,
  },
  optionCard: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: 25,
    marginBottom: 20,
    alignItems: 'center',
    borderWidth: 2,
    borderColor: 'transparent',
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 6,
    elevation: 4,
  },
  selectedCard: {
    borderColor: Colors.primaryDark,
    backgroundColor: 'rgba(146, 180, 141, 0.1)', // Very light primaryGreen
  },
  iconPlaceholder: {
    width: 70,
    height: 70,
    borderRadius: 35,
    backgroundColor: Colors.primaryLight,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 20,
  },
  iconText: {
    fontSize: 35,
  },
  optionTitle: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 10,
    color: Colors.primaryDark,
  },
  optionDescription: {
    textAlign: 'center',
    fontSize: 16,
    marginBottom: 15,
    color: Colors.darkGray,
  },
  features: {
    alignSelf: 'flex-start',
    width: '100%',
  },
  featureItem: {
    fontSize: 14,
    marginBottom: 5,
    color: Colors.darkGray,
  },
  button: {
    paddingVertical: 8,
    borderRadius: 10,
    elevation: 2,
  },
  stepIndicator: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 30,
  },
  stepDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
    backgroundColor: Colors.mediumGray,
    marginHorizontal: 5,
  },
  activeDot: {
    backgroundColor: Colors.primaryDark,
    width: 20,
  },
});

export default UserTypeScreen;
