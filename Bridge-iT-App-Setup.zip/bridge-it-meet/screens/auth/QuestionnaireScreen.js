import React, { useState } from 'react';
import { StyleSheet, View, Text, ScrollView, Alert, ImageBackground, TouchableOpacity } from 'react-native';
import { TextInput, Button, RadioButton, Divider } from 'react-native-paper';
import Checkbox from 'expo-checkbox';
import { doc, updateDoc, setDoc } from 'firebase/firestore';
import { db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const QuestionnaireScreen = ({ route, navigation }) => {
  const { userId, userType } = route.params;
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const totalPages = userType === 'jobseeker' ? 2 : 1;

  // Common profile fields
  const [gender, setGender] = useState('');
  const [location, setLocation] = useState('');
  const [citizenship, setCitizenship] = useState('');

  // Job seeker specific fields
  const [fieldOfExperience, setFieldOfExperience] = useState('');
  const [yearsOfExperience, setYearsOfExperience] = useState('');
  const [role, setRole] = useState('');
  const [bio, setBio] = useState('');

  // Field validation
  const [errors, setErrors] = useState({});

  const validatePage = (page) => {
    const newErrors = {};

    if (page === 1) {
      // Validate common fields
      if (!gender) newErrors.gender = 'Gender is required';
      if (!location) newErrors.location = 'Location is required';
      if (!citizenship) newErrors.citizenship = 'Citizenship is required';
    } else if (page === 2 && userType === 'jobseeker') {
      // Validate job seeker specific fields
      if (!fieldOfExperience) newErrors.fieldOfExperience = 'Field of experience is required';
      if (!yearsOfExperience) newErrors.yearsOfExperience = 'Years of experience is required';
      if (!role) newErrors.role = 'Role or position is required';
      if (!bio) {
        newErrors.bio = 'Bio is required';
      } else if (bio.split(/\s+/).length > 200) {
        newErrors.bio = 'Bio should be limited to 200 words';
      }
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleNext = () => {
    if (validatePage(currentPage)) {
      setCurrentPage(currentPage + 1);
    }
  };

  const handlePrevious = () => {
    setCurrentPage(currentPage - 1);
  };

  const handleSubmit = async () => {
    if (!validatePage(currentPage)) {
      return;
    }

    setLoading(true);

    try {
      // Common profile data
      const profileData = {
        userId,
        gender,
        location,
        citizenship,
      };

      // Add job seeker specific data
      if (userType === 'jobseeker') {
        Object.assign(profileData, {
          fieldOfExperience,
          yearsOfExperience,
          role,
          bio,
        });
      }

      // Create profile document
      await setDoc(doc(db, 'profiles', userId), profileData);

      // Navigate to the login screen with a success message
      Alert.alert(
        'Profile Complete',
        'Your profile has been created successfully! Please log in to continue.',
        [{ text: 'OK', onPress: () => navigation.navigate('Login') }]
      );
    } catch (error) {
      console.error('Error saving profile:', error);
      Alert.alert('Error', 'Failed to save profile. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const renderPersonalInfo = () => (
    <View style={styles.formSection}>
      <Text style={styles.sectionTitle}>Personal Information</Text>
      <Divider style={styles.divider} />

      <View style={styles.radioGroup}>
        <Text style={styles.label}>Gender</Text>
        <RadioButton.Group onValueChange={value => setGender(value)} value={gender}>
          <View style={styles.radioOptionContainer}>
            <View style={styles.radioOption}>
              <RadioButton
                value="male"
                color={Colors.primaryGreen}
                uncheckedColor={Colors.primaryDark}
              />
              <Text style={styles.radioLabel}>Male</Text>
            </View>
            <View style={styles.radioOption}>
              <RadioButton
                value="female"
                color={Colors.primaryGreen}
                uncheckedColor={Colors.primaryDark}
              />
              <Text style={styles.radioLabel}>Female</Text>
            </View>
            <View style={styles.radioOption}>
              <RadioButton
                value="other"
                color={Colors.primaryGreen}
                uncheckedColor={Colors.primaryDark}
              />
              <Text style={styles.radioLabel}>Other</Text>
            </View>
          </View>
          {errors.gender && <Text style={styles.errorText}>{errors.gender}</Text>}
        </RadioButton.Group>
      </View>

      <TextInput
        label="Country of Residence"
        value={location}
        onChangeText={setLocation}
        mode="outlined"
        style={styles.input}
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.location}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.location && <Text style={styles.errorText}>{errors.location}</Text>}

      <TextInput
        label="Citizenship"
        value={citizenship}
        onChangeText={setCitizenship}
        mode="outlined"
        style={styles.input}
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.citizenship}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.citizenship && <Text style={styles.errorText}>{errors.citizenship}</Text>}

      <View style={styles.buttonContainer}>
        {userType === 'jobseeker' ? (
          <Button
            mode="contained"
            onPress={handleNext}
            style={styles.button}
            buttonColor={Colors.primaryGreen}
            textColor={Colors.white}
          >
            Next
          </Button>
        ) : (
          <Button
            mode="contained"
            onPress={handleSubmit}
            style={styles.button}
            loading={loading}
            disabled={loading}
            buttonColor={Colors.primaryGreen}
            textColor={Colors.white}
          >
            Complete Profile
          </Button>
        )}
      </View>
    </View>
  );

  const renderProfessionalInfo = () => (
    <View style={styles.formSection}>
      <Text style={styles.sectionTitle}>Professional Information</Text>
      <Divider style={styles.divider} />

      <TextInput
        label="Field of Experience"
        value={fieldOfExperience}
        onChangeText={setFieldOfExperience}
        mode="outlined"
        style={styles.input}
        placeholder="e.g., Software Development, Data Science"
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.fieldOfExperience}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.fieldOfExperience && <Text style={styles.errorText}>{errors.fieldOfExperience}</Text>}

      <TextInput
        label="Years of Experience"
        value={yearsOfExperience}
        onChangeText={setYearsOfExperience}
        mode="outlined"
        style={styles.input}
        keyboardType="numeric"
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.yearsOfExperience}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.yearsOfExperience && <Text style={styles.errorText}>{errors.yearsOfExperience}</Text>}

      <TextInput
        label="Role or Position"
        value={role}
        onChangeText={setRole}
        mode="outlined"
        style={styles.input}
        placeholder="e.g., Frontend Developer, Data Analyst"
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.role}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.role && <Text style={styles.errorText}>{errors.role}</Text>}

      <TextInput
        label="Bio"
        value={bio}
        onChangeText={setBio}
        mode="outlined"
        style={styles.textArea}
        multiline
        numberOfLines={6}
        placeholder="Write a short bio about yourself (max 200 words)"
        outlineColor={Colors.primaryGreen}
        activeOutlineColor={Colors.primaryDark}
        error={!!errors.bio}
        theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
      />
      {errors.bio && <Text style={styles.errorText}>{errors.bio}</Text>}

      <View style={styles.bioTips}>
        <Text style={styles.bioTipsTitle}>Tips for a great bio:</Text>
        <Text style={styles.bioTipsItem}>• Highlight your key skills and expertise</Text>
        <Text style={styles.bioTipsItem}>• Mention relevant technologies and tools</Text>
        <Text style={styles.bioTipsItem}>• Share your career goals or interests</Text>
        <Text style={styles.bioTipsItem}>• Keep it concise and professional</Text>
      </View>

      <View style={styles.buttonRow}>
        <Button
          mode="outlined"
          onPress={handlePrevious}
          style={[styles.button, styles.buttonOutline]}
          buttonColor={Colors.white}
          textColor={Colors.primaryDark}
        >
          Back
        </Button>

        <Button
          mode="contained"
          onPress={handleSubmit}
          style={styles.button}
          loading={loading}
          disabled={loading}
          buttonColor={Colors.primaryGreen}
          textColor={Colors.white}
        >
          Complete Profile
        </Button>
      </View>
    </View>
  );

  return (
    <ImageBackground
      style={styles.backgroundImage}
      source={{uri: 'https://images.unsplash.com/photo-1516321318423-f06f85e504b3?q=80&w=2940'}}
    >
      <View style={styles.overlay}>
        <ScrollView style={styles.container}>
          <View style={styles.content}>
            <View style={styles.header}>
              <Text style={styles.logoText}>Bridge-iT</Text>
              <Text style={styles.progressText}>Step 3 of 3</Text>
            </View>

            <View style={styles.formContainer}>
              <Text style={styles.title}>Complete Your Profile</Text>
              <Text style={styles.subtitle}>
                Please provide the following information to enhance your {userType} profile
              </Text>

              <View style={styles.stepIndicator}>
                <View style={[styles.stepLine, { backgroundColor: currentPage >= 1 ? Colors.primaryGreen : Colors.mediumGray }]} />
                <View style={[styles.stepCircle, { backgroundColor: currentPage >= 1 ? Colors.primaryGreen : Colors.mediumGray }]}>
                  <Text style={styles.stepNumber}>1</Text>
                </View>
                <Text style={[styles.stepLabel, { color: currentPage >= 1 ? Colors.primaryDark : Colors.darkGray }]}>
                  Personal Info
                </Text>

                {userType === 'jobseeker' && (
                  <>
                    <View style={[styles.stepLine, { backgroundColor: currentPage >= 2 ? Colors.primaryGreen : Colors.mediumGray }]} />
                    <View style={[styles.stepCircle, { backgroundColor: currentPage >= 2 ? Colors.primaryGreen : Colors.mediumGray }]}>
                      <Text style={styles.stepNumber}>2</Text>
                    </View>
                    <Text style={[styles.stepLabel, { color: currentPage >= 2 ? Colors.primaryDark : Colors.darkGray }]}>
                      Professional Info
                    </Text>
                  </>
                )}
              </View>

              {currentPage === 1 && renderPersonalInfo()}
              {currentPage === 2 && renderProfessionalInfo()}
            </View>
          </View>
        </ScrollView>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(187, 190, 160, 0.85)', // primaryLight with opacity
  },
  container: {
    flex: 1,
  },
  content: {
    padding: 20,
    paddingBottom: 40,
  },
  header: {
    alignItems: 'center',
    paddingTop: 20,
    marginBottom: 20,
  },
  logoText: {
    fontSize: 32,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 5,
  },
  progressText: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginTop: 5,
  },
  formContainer: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: 20,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 8,
    textAlign: 'center',
    color: Colors.primaryDark,
  },
  subtitle: {
    fontSize: 16,
    textAlign: 'center',
    color: Colors.darkGray,
    marginBottom: 20,
  },
  stepIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 30,
    paddingHorizontal: 20,
  },
  stepLine: {
    height: 2,
    flex: 1,
    backgroundColor: Colors.primaryGreen,
  },
  stepCircle: {
    width: 30,
    height: 30,
    borderRadius: 15,
    backgroundColor: Colors.primaryGreen,
    justifyContent: 'center',
    alignItems: 'center',
    marginHorizontal: 5,
  },
  stepNumber: {
    color: Colors.white,
    fontWeight: 'bold',
  },
  stepLabel: {
    fontSize: 12,
    marginHorizontal: 5,
    color: Colors.primaryDark,
    fontWeight: 'bold',
  },
  formSection: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 20,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 10,
  },
  divider: {
    backgroundColor: Colors.primaryGreen,
    height: 2,
    marginBottom: 20,
  },
  label: {
    fontSize: 16,
    marginBottom: 10,
    color: Colors.primaryDark,
    fontWeight: '500',
  },
  radioGroup: {
    marginBottom: 20,
  },
  radioOptionContainer: {
    marginVertical: 5,
  },
  radioOption: {
    flexDirection: 'row',
    alignItems: 'center',
    marginVertical: 2,
  },
  radioLabel: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginLeft: 5,
  },
  input: {
    marginBottom: 16,
    backgroundColor: Colors.white,
    fontSize: 16,
  },
  textArea: {
    marginBottom: 16,
    backgroundColor: Colors.white,
    fontSize: 16,
    minHeight: 120,
  },
  errorText: {
    color: Colors.error,
    marginTop: -10,
    marginBottom: 12,
    marginLeft: 8,
    fontSize: 12,
  },
  bioTips: {
    backgroundColor: Colors.lightGray,
    padding: 15,
    borderRadius: 8,
    marginTop: 5,
    marginBottom: 20,
  },
  bioTipsTitle: {
    fontWeight: 'bold',
    marginBottom: 8,
    color: Colors.primaryDark,
  },
  bioTipsItem: {
    color: Colors.darkGray,
    marginBottom: 5,
  },
  buttonContainer: {
    marginTop: 20,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 20,
  },
  button: {
    flex: 1,
    marginHorizontal: 5,
    borderRadius: 8,
    paddingVertical: 5,
  },
  buttonOutline: {
    borderColor: Colors.primaryDark,
    borderWidth: 1,
  },
});

export default QuestionnaireScreen;
