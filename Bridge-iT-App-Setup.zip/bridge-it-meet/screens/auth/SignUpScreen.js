import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, KeyboardAvoidingView, Platform, ScrollView, Alert, ImageBackground } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc } from 'firebase/firestore';
import { auth, db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const SignUpScreen = ({ navigation }) => {
  const [fullName, setFullName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [secureTextEntry, setSecureTextEntry] = useState(true);
  const [confirmSecureTextEntry, setConfirmSecureTextEntry] = useState(true);

  const toggleSecureEntry = () => {
    setSecureTextEntry(!secureTextEntry);
  };

  const toggleConfirmSecureEntry = () => {
    setConfirmSecureTextEntry(!confirmSecureTextEntry);
  };

  const handleSignUp = async () => {
    // Validate inputs
    if (!fullName || !email || !password || !confirmPassword) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    if (password !== confirmPassword) {
      Alert.alert('Error', 'Passwords do not match');
      return;
    }

    if (password.length < 6) {
      Alert.alert('Error', 'Password should be at least 6 characters');
      return;
    }

    setLoading(true);

    try {
      // Create user with email and password
      const userCredential = await createUserWithEmailAndPassword(auth, email, password);
      const user = userCredential.user;

      // Store user data in Firestore
      await setDoc(doc(db, 'users', user.uid), {
        name: fullName,
        email: email,
        creationDate: new Date().toISOString(),
        uid: user.uid,
        role: null // Will be set in the next screen
      });

      // Navigate to user type selection
      navigation.navigate('UserType', { userId: user.uid });
    } catch (error) {
      Alert.alert('Sign Up Failed', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      style={styles.backgroundImage}
      source={{uri: 'https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=2942'}}
    >
      <View style={styles.overlay}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.container}
        >
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <View style={styles.logoContainer}>
              <Text style={styles.logoText}>Bridge-iT</Text>
              <Text style={styles.tagline}>Join our professional community</Text>
            </View>

            <View style={styles.formContainer}>
              <Text style={styles.title}>Create Account</Text>

              <TextInput
                label="Full Name"
                value={fullName}
                onChangeText={setFullName}
                mode="outlined"
                style={styles.input}
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <TextInput
                label="Email"
                value={email}
                onChangeText={setEmail}
                mode="outlined"
                style={styles.input}
                keyboardType="email-address"
                autoCapitalize="none"
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <TextInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                mode="outlined"
                style={styles.input}
                secureTextEntry={secureTextEntry}
                right={
                  <TextInput.Icon
                    icon={secureTextEntry ? "eye-off" : "eye"}
                    onPress={toggleSecureEntry}
                    color={Colors.primaryDark}
                  />
                }
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <TextInput
                label="Confirm Password"
                value={confirmPassword}
                onChangeText={setConfirmPassword}
                mode="outlined"
                style={styles.input}
                secureTextEntry={confirmSecureTextEntry}
                right={
                  <TextInput.Icon
                    icon={confirmSecureTextEntry ? "eye-off" : "eye"}
                    onPress={toggleConfirmSecureEntry}
                    color={Colors.primaryDark}
                  />
                }
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <Button
                mode="contained"
                onPress={handleSignUp}
                style={styles.button}
                loading={loading}
                disabled={loading}
                buttonColor={Colors.primaryGreen}
                textColor={Colors.white}
              >
                Sign Up
              </Button>

              <View style={styles.signupSteps}>
                <Text style={styles.stepsTitle}>Registration Steps:</Text>
                <View style={styles.step}>
                  <View style={styles.stepNumber}><Text style={styles.stepNumberText}>1</Text></View>
                  <Text style={styles.stepText}>Create account</Text>
                </View>
                <View style={styles.step}>
                  <View style={styles.stepNumber}><Text style={styles.stepNumberText}>2</Text></View>
                  <Text style={styles.stepText}>Select account type (Job Seeker/Employer)</Text>
                </View>
                <View style={styles.step}>
                  <View style={styles.stepNumber}><Text style={styles.stepNumberText}>3</Text></View>
                  <Text style={styles.stepText}>Complete profile questionnaire</Text>
                </View>
              </View>

              <View style={styles.footerText}>
                <Text style={styles.footerTextRegular}>Already have an account? </Text>
                <TouchableOpacity onPress={() => navigation.navigate('Login')}>
                  <Text style={styles.footerTextBold}>Login</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(187, 190, 160, 0.8)', // primaryLight with opacity
  },
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
    paddingBottom: 40,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 30,
  },
  logoText: {
    fontSize: 42,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 10,
  },
  tagline: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginTop: 10,
  },
  formContainer: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: 25,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: Colors.primaryDark,
  },
  input: {
    marginBottom: 16,
    backgroundColor: Colors.white,
    fontSize: 16,
  },
  button: {
    marginTop: 16,
    paddingVertical: 8,
    borderRadius: 8,
    elevation: 2,
  },
  signupSteps: {
    marginTop: 25,
    backgroundColor: Colors.lightGray,
    padding: 15,
    borderRadius: 10,
  },
  stepsTitle: {
    fontWeight: 'bold',
    fontSize: 16,
    color: Colors.primaryDark,
    marginBottom: 10,
  },
  step: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 8,
  },
  stepNumber: {
    width: 24,
    height: 24,
    borderRadius: 12,
    backgroundColor: Colors.primaryGreen,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 10,
  },
  stepNumberText: {
    color: Colors.white,
    fontWeight: 'bold',
  },
  stepText: {
    color: Colors.darkGray,
    flex: 1,
  },
  footerText: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  footerTextRegular: {
    color: Colors.darkGray,
    fontSize: 16,
  },
  footerTextBold: {
    color: Colors.primaryDark,
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default SignUpScreen;
