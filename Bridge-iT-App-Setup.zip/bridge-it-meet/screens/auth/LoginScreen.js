import React, { useState } from 'react';
import { StyleSheet, View, Text, TouchableOpacity, Image, KeyboardAvoidingView, Platform, ScrollView, Alert, ImageBackground } from 'react-native';
import { TextInput, Button } from 'react-native-paper';
import { signInWithEmailAndPassword } from 'firebase/auth';
import { auth } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const LoginScreen = ({ navigation }) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [secureTextEntry, setSecureTextEntry] = useState(true);

  const toggleSecureEntry = () => {
    setSecureTextEntry(!secureTextEntry);
  };

  const handleLogin = async () => {
    if (!email || !password) {
      Alert.alert('Error', 'Please fill in all fields');
      return;
    }

    setLoading(true);

    try {
      await signInWithEmailAndPassword(auth, email, password);
      // Navigation is handled by the auth state listener in App.js
    } catch (error) {
      Alert.alert('Login Failed', error.message);
      setLoading(false);
    }
  };

  return (
    <ImageBackground
      style={styles.backgroundImage}
      source={{uri: 'https://images.unsplash.com/photo-1522071820081-009f0129c71c?q=80&w=2940'}}
    >
      <View style={styles.overlay}>
        <KeyboardAvoidingView
          behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
          style={styles.container}
        >
          <ScrollView contentContainerStyle={styles.scrollContent}>
            <View style={styles.logoContainer}>
              <Text style={styles.logoText}>Bridge-iT</Text>
              <Text style={styles.tagline}>Connecting Talent with Opportunity</Text>
            </View>

            <View style={styles.formContainer}>
              <Text style={styles.title}>Login</Text>

              <TextInput
                label="Email"
                value={email}
                onChangeText={setEmail}
                mode="outlined"
                style={styles.input}
                keyboardType="email-address"
                autoCapitalize="none"
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <TextInput
                label="Password"
                value={password}
                onChangeText={setPassword}
                mode="outlined"
                style={styles.input}
                secureTextEntry={secureTextEntry}
                right={
                  <TextInput.Icon
                    icon={secureTextEntry ? "eye-off" : "eye"}
                    onPress={toggleSecureEntry}
                    color={Colors.primaryDark}
                  />
                }
                outlineColor={Colors.primaryGreen}
                activeOutlineColor={Colors.primaryDark}
                theme={{ colors: { text: Colors.primaryDark, placeholder: Colors.darkGray } }}
              />

              <Button
                mode="contained"
                onPress={handleLogin}
                style={styles.button}
                loading={loading}
                disabled={loading}
                buttonColor={Colors.primaryGreen}
                textColor={Colors.white}
              >
                Login
              </Button>

              <View style={styles.footerText}>
                <Text style={styles.footerTextRegular}>Don't have an account? </Text>
                <TouchableOpacity onPress={() => navigation.navigate('SignUp')}>
                  <Text style={styles.footerTextBold}>Sign Up</Text>
                </TouchableOpacity>
              </View>
            </View>
          </ScrollView>
        </KeyboardAvoidingView>
      </View>
    </ImageBackground>
  );
};

const styles = StyleSheet.create({
  backgroundImage: {
    flex: 1,
    width: '100%',
    height: '100%',
  },
  overlay: {
    flex: 1,
    backgroundColor: 'rgba(187, 190, 160, 0.8)', // primaryLight with opacity
  },
  container: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    justifyContent: 'center',
    padding: 20,
  },
  logoContainer: {
    alignItems: 'center',
    marginBottom: 40,
  },
  logoText: {
    fontSize: 42,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    textShadowColor: 'rgba(255, 255, 255, 0.5)',
    textShadowOffset: { width: 1, height: 1 },
    textShadowRadius: 10,
  },
  tagline: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginTop: 10,
  },
  formContainer: {
    backgroundColor: Colors.white,
    borderRadius: 15,
    padding: 25,
    shadowColor: Colors.black,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.2,
    shadowRadius: 8,
    elevation: 5,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 20,
    textAlign: 'center',
    color: Colors.primaryDark,
  },
  input: {
    marginBottom: 16,
    backgroundColor: Colors.white,
    fontSize: 16,
  },
  button: {
    marginTop: 16,
    paddingVertical: 8,
    borderRadius: 8,
    elevation: 2,
  },
  footerText: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 20,
  },
  footerTextRegular: {
    color: Colors.darkGray,
    fontSize: 16,
  },
  footerTextBold: {
    color: Colors.primaryDark,
    fontWeight: 'bold',
    fontSize: 16,
  },
});

export default LoginScreen;
