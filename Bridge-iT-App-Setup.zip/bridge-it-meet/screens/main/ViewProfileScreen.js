import React from 'react';
import { StyleSheet, View, ScrollView, Text, TouchableOpacity } from 'react-native';
import { Avatar, Button, Divider } from 'react-native-paper';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const ViewProfileScreen = ({ route, navigation }) => {
  const { user } = route.params;

  const handleContact = () => {
    navigation.navigate('Chat', {
      receiverId: user.id,
      receiverName: user.name
    });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Avatar.Text
          size={80}
          label={user?.name ? user.name.substring(0, 2).toUpperCase() : '??'}
          backgroundColor={Colors.primaryGreen}
          color={Colors.white}
          style={styles.avatar}
        />
        <View style={styles.userInfo}>
          <Text style={styles.userName}>{user?.name}</Text>
          <Text style={styles.userType}>{user?.role === 'jobseeker' ? 'Job Seeker' : 'Employer'}</Text>
          <Text style={styles.userEmail}>{user?.email}</Text>
        </View>
      </View>

      <View style={styles.profileContent}>
        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Personal Information</Text>
          <Divider style={styles.divider} />

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Location:</Text>
            <Text style={styles.infoValue}>{user?.location || 'Not specified'}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Gender:</Text>
            <Text style={styles.infoValue}>{user?.gender || 'Not specified'}</Text>
          </View>

          <View style={styles.infoRow}>
            <Text style={styles.infoLabel}>Citizenship:</Text>
            <Text style={styles.infoValue}>{user?.citizenship || 'Not specified'}</Text>
          </View>
        </View>

        {user?.role === 'jobseeker' && (
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Professional Information</Text>
            <Divider style={styles.divider} />

            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Field of Experience:</Text>
              <Text style={styles.infoValue}>{user?.fieldOfExperience || 'Not specified'}</Text>
            </View>

            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Years of Experience:</Text>
              <Text style={styles.infoValue}>{user?.yearsOfExperience || 'Not specified'}</Text>
            </View>

            <View style={styles.infoRow}>
              <Text style={styles.infoLabel}>Role or Position:</Text>
              <Text style={styles.infoValue}>{user?.role || 'Not specified'}</Text>
            </View>

            <Text style={styles.bioLabel}>Bio:</Text>
            <Text style={styles.bioText}>{user?.bio || 'No bio provided'}</Text>
          </View>
        )}

        <Button
          mode="contained"
          onPress={handleContact}
          style={styles.contactButton}
          buttonColor={Colors.primaryGreen}
          textColor={Colors.white}
          icon="message"
        >
          Contact {user?.name.split(' ')[0]}
        </Button>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  header: {
    backgroundColor: Colors.primaryLight,
    padding: 20,
    alignItems: 'center',
  },
  avatar: {
    marginVertical: 10,
  },
  userInfo: {
    alignItems: 'center',
    marginTop: 10,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  userType: {
    fontSize: 18,
    color: Colors.primaryGreen,
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 16,
    color: Colors.darkGray,
  },
  profileContent: {
    padding: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  divider: {
    backgroundColor: Colors.primaryGreen,
    height: 1,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    width: 150,
  },
  infoValue: {
    fontSize: 16,
    color: Colors.darkGray,
    flex: 1,
  },
  bioLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginTop: 10,
    marginBottom: 5,
  },
  bioText: {
    fontSize: 16,
    color: Colors.darkGray,
    lineHeight: 22,
  },
  contactButton: {
    marginTop: 20,
  },
});

export default ViewProfileScreen;
