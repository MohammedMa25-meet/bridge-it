import React, { useState, useEffect } from 'react';
import { StyleSheet, View, ScrollView, Text, TouchableOpacity, Alert } from 'react-native';
import { Avatar, TextInput, Button, Divider, ActivityIndicator } from 'react-native-paper';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { getAuth, signOut } from 'firebase/auth';
import { db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const ProfileScreen = ({ navigation }) => {
  const [profile, setProfile] = useState(null);
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [editMode, setEditMode] = useState(false);

  // Editable fields
  const [name, setName] = useState('');
  const [location, setLocation] = useState('');
  const [fieldOfExperience, setFieldOfExperience] = useState('');
  const [yearsOfExperience, setYearsOfExperience] = useState('');
  const [role, setRole] = useState('');
  const [bio, setBio] = useState('');

  const auth = getAuth();
  const currentUser = auth.currentUser;

  useEffect(() => {
    const fetchProfile = async () => {
      if (!currentUser) return;

      try {
        // Fetch user document
        const userDoc = await getDoc(doc(db, 'users', currentUser.uid));

        if (!userDoc.exists()) {
          setLoading(false);
          return;
        }

        const userData = userDoc.data();
        setUser(userData);

        // Fetch profile document
        const profileDoc = await getDoc(doc(db, 'profiles', currentUser.uid));

        if (profileDoc.exists()) {
          const profileData = profileDoc.data();
          setProfile(profileData);

          // Set editable fields
          setName(userData.name || '');
          setLocation(profileData.location || '');
          setFieldOfExperience(profileData.fieldOfExperience || '');
          setYearsOfExperience(profileData.yearsOfExperience || '');
          setRole(profileData.role || '');
          setBio(profileData.bio || '');
        }
      } catch (error) {
        console.error('Error fetching profile:', error);
        Alert.alert('Error', 'Failed to load profile information');
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, [currentUser]);

  const handleLogout = async () => {
    try {
      await signOut(auth);
      // Navigation will be handled by the auth state listener in App.js
    } catch (error) {
      Alert.alert('Error', 'Failed to log out');
    }
  };

  const handleSaveProfile = async () => {
    setSaving(true);

    try {
      // Validate fields
      if (!name || !location) {
        Alert.alert('Error', 'Name and location are required');
        setSaving(false);
        return;
      }

      // Update user document
      await updateDoc(doc(db, 'users', currentUser.uid), {
        name,
      });

      // Update profile document
      const profileData = {
        location,
      };

      if (user.role === 'jobseeker') {
        Object.assign(profileData, {
          fieldOfExperience,
          yearsOfExperience,
          role,
          bio,
        });
      }

      await updateDoc(doc(db, 'profiles', currentUser.uid), profileData);

      // Update local state
      setUser({ ...user, name });
      setProfile({ ...profile, ...profileData });

      setEditMode(false);
      Alert.alert('Success', 'Profile updated successfully');
    } catch (error) {
      console.error('Error updating profile:', error);
      Alert.alert('Error', 'Failed to update profile');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primaryGreen} />
        <Text style={styles.loadingText}>Loading profile...</Text>
      </View>
    );
  }

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Avatar.Text
          size={80}
          label={user?.name ? user.name.substring(0, 2).toUpperCase() : '??'}
          backgroundColor={Colors.primaryGreen}
          color={Colors.white}
          style={styles.avatar}
        />
        {!editMode ? (
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{user?.name}</Text>
            <Text style={styles.userType}>{user?.role === 'jobseeker' ? 'Job Seeker' : 'Employer'}</Text>
            <Text style={styles.userEmail}>{user?.email}</Text>
          </View>
        ) : (
          <TextInput
            label="Full Name"
            value={name}
            onChangeText={setName}
            mode="outlined"
            style={styles.nameInput}
            outlineColor={Colors.primaryGreen}
            activeOutlineColor={Colors.primaryDark}
          />
        )}
      </View>

      <View style={styles.profileContent}>
        {!editMode ? (
          <>
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>Personal Information</Text>
              <Divider style={styles.divider} />

              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Location:</Text>
                <Text style={styles.infoValue}>{profile?.location || 'Not specified'}</Text>
              </View>

              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Gender:</Text>
                <Text style={styles.infoValue}>{profile?.gender || 'Not specified'}</Text>
              </View>

              <View style={styles.infoRow}>
                <Text style={styles.infoLabel}>Citizenship:</Text>
                <Text style={styles.infoValue}>{profile?.citizenship || 'Not specified'}</Text>
              </View>
            </View>

            {user?.role === 'jobseeker' && (
              <View style={styles.section}>
                <Text style={styles.sectionTitle}>Professional Information</Text>
                <Divider style={styles.divider} />

                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Field of Experience:</Text>
                  <Text style={styles.infoValue}>{profile?.fieldOfExperience || 'Not specified'}</Text>
                </View>

                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Years of Experience:</Text>
                  <Text style={styles.infoValue}>{profile?.yearsOfExperience || 'Not specified'}</Text>
                </View>

                <View style={styles.infoRow}>
                  <Text style={styles.infoLabel}>Role or Position:</Text>
                  <Text style={styles.infoValue}>{profile?.role || 'Not specified'}</Text>
                </View>

                <Text style={styles.bioLabel}>Bio:</Text>
                <Text style={styles.bioText}>{profile?.bio || 'No bio provided'}</Text>
              </View>
            )}

            <Button
              mode="outlined"
              onPress={() => setEditMode(true)}
              style={styles.editButton}
              buttonColor={Colors.white}
              textColor={Colors.primaryDark}
              icon="pencil"
            >
              Edit Profile
            </Button>
          </>
        ) : (
          <>
            <Text style={styles.sectionTitle}>Edit Profile</Text>
            <Divider style={styles.divider} />

            <TextInput
              label="Location"
              value={location}
              onChangeText={setLocation}
              mode="outlined"
              style={styles.input}
              outlineColor={Colors.primaryGreen}
              activeOutlineColor={Colors.primaryDark}
            />

            {user?.role === 'jobseeker' && (
              <>
                <TextInput
                  label="Field of Experience"
                  value={fieldOfExperience}
                  onChangeText={setFieldOfExperience}
                  mode="outlined"
                  style={styles.input}
                  outlineColor={Colors.primaryGreen}
                  activeOutlineColor={Colors.primaryDark}
                />

                <TextInput
                  label="Years of Experience"
                  value={yearsOfExperience}
                  onChangeText={setYearsOfExperience}
                  mode="outlined"
                  style={styles.input}
                  keyboardType="numeric"
                  outlineColor={Colors.primaryGreen}
                  activeOutlineColor={Colors.primaryDark}
                />

                <TextInput
                  label="Role or Position"
                  value={role}
                  onChangeText={setRole}
                  mode="outlined"
                  style={styles.input}
                  outlineColor={Colors.primaryGreen}
                  activeOutlineColor={Colors.primaryDark}
                />

                <TextInput
                  label="Bio"
                  value={bio}
                  onChangeText={setBio}
                  mode="outlined"
                  style={styles.textArea}
                  multiline
                  numberOfLines={6}
                  outlineColor={Colors.primaryGreen}
                  activeOutlineColor={Colors.primaryDark}
                />
              </>
            )}

            <View style={styles.buttonRow}>
              <Button
                mode="outlined"
                onPress={() => setEditMode(false)}
                style={[styles.actionButton, styles.cancelButton]}
                buttonColor={Colors.white}
                textColor={Colors.darkGray}
              >
                Cancel
              </Button>

              <Button
                mode="contained"
                onPress={handleSaveProfile}
                style={styles.actionButton}
                loading={saving}
                disabled={saving}
                buttonColor={Colors.primaryGreen}
                textColor={Colors.white}
              >
                Save
              </Button>
            </View>
          </>
        )}

        <View style={styles.logoutContainer}>
          <Button
            mode="outlined"
            onPress={handleLogout}
            style={styles.logoutButton}
            buttonColor={Colors.white}
            textColor={Colors.error}
            icon="logout"
          >
            Log Out
          </Button>
        </View>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
  loadingText: {
    marginTop: 10,
    color: Colors.primaryDark,
  },
  header: {
    backgroundColor: Colors.primaryLight,
    padding: 20,
    alignItems: 'center',
  },
  avatar: {
    marginVertical: 10,
  },
  userInfo: {
    alignItems: 'center',
    marginTop: 10,
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  userType: {
    fontSize: 18,
    color: Colors.primaryGreen,
    marginBottom: 5,
  },
  userEmail: {
    fontSize: 16,
    color: Colors.darkGray,
  },
  nameInput: {
    marginTop: 10,
    backgroundColor: Colors.white,
    width: '100%',
  },
  profileContent: {
    padding: 20,
  },
  section: {
    marginBottom: 20,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  divider: {
    backgroundColor: Colors.primaryGreen,
    height: 1,
    marginBottom: 15,
  },
  infoRow: {
    flexDirection: 'row',
    marginBottom: 10,
  },
  infoLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    width: 150,
  },
  infoValue: {
    fontSize: 16,
    color: Colors.darkGray,
    flex: 1,
  },
  bioLabel: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginTop: 10,
    marginBottom: 5,
  },
  bioText: {
    fontSize: 16,
    color: Colors.darkGray,
    lineHeight: 22,
  },
  input: {
    marginBottom: 16,
    backgroundColor: Colors.white,
  },
  textArea: {
    marginBottom: 16,
    backgroundColor: Colors.white,
    height: 120,
  },
  buttonRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 10,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 5,
  },
  cancelButton: {
    borderColor: Colors.darkGray,
  },
  editButton: {
    marginTop: 20,
    borderColor: Colors.primaryDark,
  },
  logoutContainer: {
    marginTop: 40,
    borderTopWidth: 1,
    borderTopColor: Colors.lightGray,
    paddingTop: 20,
  },
  logoutButton: {
    borderColor: Colors.error,
  },
});

export default ProfileScreen;
