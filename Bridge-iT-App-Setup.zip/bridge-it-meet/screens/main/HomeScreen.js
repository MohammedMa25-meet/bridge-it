import React, { useState, useEffect } from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, ActivityIndicator } from 'react-native';
import { Card, Avatar, Button } from 'react-native-paper';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';
import { db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const HomeScreen = ({ navigation }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [currentUserData, setCurrentUserData] = useState(null);
  const auth = getAuth();
  const currentUser = auth.currentUser;

  useEffect(() => {
    const fetchUsers = async () => {
      if (!currentUser) return;

      try {
        // First get current user's role
        const userDocRef = query(
          collection(db, 'users'),
          where('uid', '==', currentUser.uid)
        );
        const userSnapshot = await getDocs(userDocRef);

        if (userSnapshot.empty) {
          console.log('No user document found');
          setLoading(false);
          return;
        }

        const userData = userSnapshot.docs[0].data();
        setCurrentUserData(userData);

        // Fetch users with opposite role
        const userRole = userData.role;
        const targetRole = userRole === 'jobseeker' ? 'employer' : 'jobseeker';

        const usersRef = query(
          collection(db, 'users'),
          where('role', '==', targetRole)
        );

        const querySnapshot = await getDocs(usersRef);
        const fetchedUsers = [];

        // Get user IDs to fetch profiles
        const userIds = querySnapshot.docs.map(doc => doc.data().uid);

        // Fetch profiles for each user
        for (const userId of userIds) {
          const profileRef = query(
            collection(db, 'profiles'),
            where('userId', '==', userId)
          );

          const profileSnapshot = await getDocs(profileRef);

          if (!profileSnapshot.empty) {
            const userDoc = querySnapshot.docs.find(doc => doc.data().uid === userId);
            const userData = userDoc.data();
            const profileData = profileSnapshot.docs[0].data();

            fetchedUsers.push({
              ...userData,
              ...profileData,
              id: userId,
            });
          }
        }

        setUsers(fetchedUsers);
      } catch (error) {
        console.error('Error fetching users:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchUsers();
  }, [currentUser]);

  const handleViewProfile = (user) => {
    navigation.navigate('ViewProfile', { user });
  };

  const handleContact = (user) => {
    navigation.navigate('Chat', {
      receiverId: user.id,
      receiverName: user.name
    });
  };

  const renderUserItem = ({ item }) => (
    <Card style={styles.card}>
      <Card.Content>
        <View style={styles.cardHeader}>
          <Avatar.Text
            size={60}
            label={item.name ? item.name.substring(0, 2).toUpperCase() : '??'}
            backgroundColor={Colors.primaryGreen}
            color={Colors.white}
          />
          <View style={styles.userInfo}>
            <Text style={styles.userName}>{item.name}</Text>
            {item.role === 'jobseeker' ? (
              <Text style={styles.userRole}>{item.role || 'No role specified'}</Text>
            ) : (
              <Text style={styles.userRole}>Employer</Text>
            )}
            <Text style={styles.userLocation}>{item.location || 'Location not specified'}</Text>
          </View>
        </View>

        {item.role === 'jobseeker' && (
          <View style={styles.jobSeekerInfo}>
            <Text style={styles.infoLabel}>Field: <Text style={styles.infoValue}>{item.fieldOfExperience || 'Not specified'}</Text></Text>
            <Text style={styles.infoLabel}>Experience: <Text style={styles.infoValue}>{item.yearsOfExperience || 'Not specified'} years</Text></Text>
          </View>
        )}
      </Card.Content>

      <Card.Actions style={styles.cardActions}>
        <Button
          mode="outlined"
          onPress={() => handleViewProfile(item)}
          style={styles.actionButton}
          buttonColor={Colors.white}
          textColor={Colors.primaryDark}
        >
          View Profile
        </Button>
        <Button
          mode="contained"
          onPress={() => handleContact(item)}
          style={styles.actionButton}
          buttonColor={Colors.primaryGreen}
          textColor={Colors.white}
        >
          Contact
        </Button>
      </Card.Actions>
    </Card>
  );

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primaryGreen} />
        <Text style={styles.loadingText}>Loading...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>
          {currentUserData?.role === 'jobseeker'
            ? 'Available Employers'
            : 'Available Job Seekers'}
        </Text>
        <Text style={styles.subtitle}>
          {currentUserData?.role === 'jobseeker'
            ? 'Connect with employers looking for talent'
            : 'Find talented professionals for your team'}
        </Text>
      </View>

      {users.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No users found</Text>
        </View>
      ) : (
        <FlatList
          data={users}
          renderItem={renderUserItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
          showsVerticalScrollIndicator={false}
        />
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  header: {
    backgroundColor: Colors.primaryLight,
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.darkGray,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.white,
  },
  loadingText: {
    marginTop: 10,
    color: Colors.primaryDark,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    color: Colors.darkGray,
    textAlign: 'center',
  },
  listContainer: {
    padding: 16,
  },
  card: {
    marginBottom: 16,
    borderRadius: 10,
    backgroundColor: Colors.white,
    elevation: 2,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  userInfo: {
    marginLeft: 16,
    flex: 1,
  },
  userName: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
  },
  userRole: {
    fontSize: 16,
    color: Colors.primaryGreen,
    marginTop: 2,
  },
  userLocation: {
    fontSize: 14,
    color: Colors.darkGray,
    marginTop: 2,
  },
  jobSeekerInfo: {
    marginTop: 8,
    padding: 12,
    backgroundColor: Colors.lightGray,
    borderRadius: 8,
  },
  infoLabel: {
    fontSize: 14,
    color: Colors.primaryDark,
    marginBottom: 4,
  },
  infoValue: {
    fontWeight: 'normal',
    color: Colors.darkGray,
  },
  cardActions: {
    justifyContent: 'space-between',
    borderTopWidth: 1,
    borderTopColor: Colors.lightGray,
    padding: 8,
  },
  actionButton: {
    flex: 1,
    marginHorizontal: 4,
  },
});

export default HomeScreen;
