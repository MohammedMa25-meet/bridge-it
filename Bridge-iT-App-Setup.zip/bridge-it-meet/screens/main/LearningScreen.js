import React from 'react';
import { StyleSheet, View, Text, FlatList, TouchableOpacity, Alert, Image } from 'react-native';
import { Card } from 'react-native-paper';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

// Placeholder for course data
const coursesData = [
  {
    id: '1',
    title: 'Introduction to JavaScript',
    description: 'Learn the basics of JavaScript programming language',
    duration: '6 weeks',
    image: require('../../assets/images/react-logo.png'),
  },
  {
    id: '2',
    title: 'React Native Fundamentals',
    description: 'Build cross-platform mobile apps with React Native',
    duration: '8 weeks',
    image: require('../../assets/images/react-logo.png'),
  },
  {
    id: '3',
    title: 'Node.js Backend Development',
    description: 'Create robust backend systems with Node.js',
    duration: '10 weeks',
    image: require('../../assets/images/react-logo.png'),
  },
  {
    id: '4',
    title: 'Full Stack Development',
    description: 'Master both frontend and backend development',
    duration: '12 weeks',
    image: require('../../assets/images/react-logo.png'),
  },
  {
    id: '5',
    title: 'Data Structures & Algorithms',
    description: 'Prepare for technical interviews with DS&A',
    duration: '8 weeks',
    image: require('../../assets/images/react-logo.png'),
  },
];

const LearningScreen = () => {
  const handleCoursePress = (course) => {
    Alert.alert(
      'Course Unavailable',
      'This course is currently unavailable. Please try again later.',
      [{ text: 'OK' }]
    );
  };

  const renderCourseItem = ({ item }) => (
    <TouchableOpacity onPress={() => handleCoursePress(item)}>
      <Card style={styles.card}>
        <View style={styles.cardContent}>
          <Image source={item.image} style={styles.courseImage} />
          <View style={styles.courseInfo}>
            <Text style={styles.courseTitle}>{item.title}</Text>
            <Text style={styles.courseDescription}>{item.description}</Text>
            <Text style={styles.courseDuration}>Duration: {item.duration}</Text>
          </View>
        </View>
      </Card>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Bridge Learning</Text>
        <Text style={styles.subtitle}>Enhance your skills with our courses</Text>
      </View>

      <FlatList
        data={coursesData}
        renderItem={renderCourseItem}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.listContainer}
        showsVerticalScrollIndicator={false}
      />

      <View style={styles.comingSoonBanner}>
        <Text style={styles.comingSoonText}>
          More courses coming soon!
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  header: {
    backgroundColor: Colors.primaryLight,
    padding: 20,
    paddingTop: 10,
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 16,
    color: Colors.darkGray,
  },
  listContainer: {
    padding: 16,
    paddingBottom: 80, // Extra padding for the banner
  },
  card: {
    marginBottom: 16,
    borderRadius: 10,
    backgroundColor: Colors.white,
    elevation: 2,
  },
  cardContent: {
    flexDirection: 'row',
    padding: 16,
  },
  courseImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    backgroundColor: Colors.lightGray,
  },
  courseInfo: {
    marginLeft: 16,
    flex: 1,
  },
  courseTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 5,
  },
  courseDescription: {
    fontSize: 14,
    color: Colors.darkGray,
    marginBottom: 5,
  },
  courseDuration: {
    fontSize: 14,
    color: Colors.primaryGreen,
    fontWeight: 'bold',
  },
  comingSoonBanner: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: Colors.primaryLight,
    padding: 15,
    alignItems: 'center',
    borderTopWidth: 1,
    borderTopColor: Colors.primaryGreen,
  },
  comingSoonText: {
    fontSize: 16,
    fontWeight: 'bold',
    color: Colors.primaryDark,
  },
});

export default LearningScreen;
