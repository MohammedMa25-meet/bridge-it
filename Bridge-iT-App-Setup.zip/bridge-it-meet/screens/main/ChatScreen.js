import React, { useState, useEffect, useRef } from 'react';
import { StyleSheet, View, Text, FlatList, KeyboardAvoidingView, Platform, TextInput, TouchableOpacity, ActivityIndicator } from 'react-native';
import { IconButton } from 'react-native-paper';
import { getAuth } from 'firebase/auth';
import { collection, addDoc, query, where, orderBy, onSnapshot, doc, getDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../../firebase/config';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

const ChatScreen = ({ route, navigation }) => {
  const { receiverId, receiverName } = route.params;
  const [messages, setMessages] = useState([]);
  const [messageText, setMessageText] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const [receiverInfo, setReceiverInfo] = useState(null);

  const auth = getAuth();
  const currentUser = auth.currentUser;
  const flatListRef = useRef(null);

  // Set the chat header title
  useEffect(() => {
    navigation.setOptions({
      title: receiverName || 'Chat',
    });
  }, [navigation, receiverName]);

  // Fetch receiver info
  useEffect(() => {
    const fetchReceiverInfo = async () => {
      try {
        const userDoc = await getDoc(doc(db, 'users', receiverId));
        if (userDoc.exists()) {
          setReceiverInfo(userDoc.data());
        }
      } catch (error) {
        console.error('Error fetching receiver info:', error);
      }
    };

    fetchReceiverInfo();
  }, [receiverId]);

  // Fetch and listen to messages
  useEffect(() => {
    if (!currentUser) return;

    const chatQuery = query(
      collection(db, 'messages'),
      where('participants', 'array-contains', currentUser.uid),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(chatQuery, (snapshot) => {
      const fetchedMessages = [];

      snapshot.forEach((doc) => {
        const messageData = doc.data();

        // Only include messages between these two users
        if (
          (messageData.senderId === currentUser.uid && messageData.receiverId === receiverId) ||
          (messageData.senderId === receiverId && messageData.receiverId === currentUser.uid)
        ) {
          fetchedMessages.push({
            id: doc.id,
            ...messageData,
          });
        }
      });

      setMessages(fetchedMessages);
      setLoading(false);
    });

    return () => unsubscribe();
  }, [currentUser, receiverId]);

  // Scroll to bottom when new messages arrive
  useEffect(() => {
    if (messages.length > 0 && flatListRef.current) {
      setTimeout(() => {
        flatListRef.current.scrollToEnd({ animated: true });
      }, 200);
    }
  }, [messages]);

  const handleSendMessage = async () => {
    if (!messageText.trim() || sending) return;

    setSending(true);

    try {
      const messageData = {
        senderId: currentUser.uid,
        senderName: currentUser.displayName || currentUser.email,
        receiverId: receiverId,
        receiverName: receiverName,
        text: messageText.trim(),
        timestamp: serverTimestamp(),
        read: false,
        participants: [currentUser.uid, receiverId],
      };

      await addDoc(collection(db, 'messages'), messageData);
      setMessageText('');
    } catch (error) {
      console.error('Error sending message:', error);
    } finally {
      setSending(false);
    }
  };

  const renderMessageItem = ({ item }) => {
    const isOwnMessage = item.senderId === currentUser.uid;

    return (
      <View style={[styles.messageContainer, isOwnMessage ? styles.ownMessage : styles.otherMessage]}>
        <View style={[styles.messageBubble, isOwnMessage ? styles.ownBubble : styles.otherBubble]}>
          <Text style={[styles.messageText, isOwnMessage ? styles.ownMessageText : styles.otherMessageText]}>
            {item.text}
          </Text>
          <Text style={[styles.messageTime, isOwnMessage ? styles.ownMessageTime : styles.otherMessageTime]}>
            {item.timestamp ? new Date(item.timestamp.toDate()).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }) : '...'}
          </Text>
        </View>
      </View>
    );
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={Colors.primaryGreen} />
        <Text style={styles.loadingText}>Loading messages...</Text>
      </View>
    );
  }

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
      keyboardVerticalOffset={Platform.OS === 'ios' ? 90 : 0}
    >
      {messages.length === 0 ? (
        <View style={styles.emptyContainer}>
          <Text style={styles.emptyText}>No messages yet</Text>
          <Text style={styles.emptySubtext}>Send a message to start the conversation</Text>
        </View>
      ) : (
        <FlatList
          ref={flatListRef}
          data={messages}
          renderItem={renderMessageItem}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.messagesList}
          showsVerticalScrollIndicator={true}
        />
      )}

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.input}
          placeholder="Type a message..."
          value={messageText}
          onChangeText={setMessageText}
          multiline
          maxLength={500}
        />
        <TouchableOpacity
          style={[styles.sendButton, !messageText.trim() && styles.disabledSendButton]}
          onPress={handleSendMessage}
          disabled={!messageText.trim() || sending}
        >
          <IconButton
            icon="send"
            size={24}
            iconColor={messageText.trim() ? Colors.white : Colors.mediumGray}
          />
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: Colors.white,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    marginTop: 10,
    color: Colors.primaryDark,
  },
  emptyContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  emptyText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
    marginBottom: 8,
  },
  emptySubtext: {
    fontSize: 16,
    color: Colors.darkGray,
    textAlign: 'center',
  },
  messagesList: {
    paddingHorizontal: 16,
    paddingVertical: 20,
  },
  messageContainer: {
    marginBottom: 16,
    maxWidth: '80%',
  },
  ownMessage: {
    alignSelf: 'flex-end',
  },
  otherMessage: {
    alignSelf: 'flex-start',
  },
  messageBubble: {
    borderRadius: 18,
    padding: 12,
    minWidth: 80,
  },
  ownBubble: {
    backgroundColor: Colors.primaryGreen,
  },
  otherBubble: {
    backgroundColor: Colors.lightGray,
  },
  messageText: {
    fontSize: 16,
    marginBottom: 4,
  },
  ownMessageText: {
    color: Colors.white,
  },
  otherMessageText: {
    color: Colors.primaryDark,
  },
  messageTime: {
    fontSize: 12,
    alignSelf: 'flex-end',
  },
  ownMessageTime: {
    color: 'rgba(255,255,255,0.7)',
  },
  otherMessageTime: {
    color: Colors.darkGray,
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 10,
    borderTopWidth: 1,
    borderTopColor: Colors.lightGray,
    backgroundColor: Colors.white,
  },
  input: {
    flex: 1,
    height: 40,
    backgroundColor: Colors.lightGray,
    borderRadius: 20,
    paddingHorizontal: 15,
    paddingVertical: 8,
    marginRight: 10,
    fontSize: 16,
    color: Colors.primaryDark,
  },
  sendButton: {
    backgroundColor: Colors.primaryGreen,
    borderRadius: 30,
    padding: 0,
    justifyContent: 'center',
    alignItems: 'center',
  },
  disabledSendButton: {
    backgroundColor: Colors.lightGray,
  },
});

export default ChatScreen;
