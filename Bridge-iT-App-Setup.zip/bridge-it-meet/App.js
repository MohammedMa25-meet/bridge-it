import React, { useState, useEffect } from 'react';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { StatusBar } from 'expo-status-bar';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { auth } from './firebase/config';
import { onAuthStateChanged } from 'firebase/auth';
import { Provider as PaperProvider } from 'react-native-paper';
import { StyleSheet, Image, Text, View, TouchableOpacity } from 'react-native';

// Define colors directly in this file to avoid import issues
const Colors = {
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',
};

// Auth screens
import LoginScreen from './screens/auth/LoginScreen';
import SignUpScreen from './screens/auth/SignUpScreen';
import UserTypeScreen from './screens/auth/UserTypeScreen';
import QuestionnaireScreen from './screens/auth/QuestionnaireScreen';

// Main tabs
import HomeScreen from './screens/main/HomeScreen';
import ProfileScreen from './screens/main/ProfileScreen';
import LearningScreen from './screens/main/LearningScreen';
import ViewProfileScreen from './screens/main/ViewProfileScreen';
import ChatScreen from './screens/main/ChatScreen';

// Create the navigation stacks
const Stack = createStackNavigator();
const Tab = createBottomTabNavigator();

// Bottom tab navigator
function BottomTabs() {
  return (
    <Tab.Navigator
      screenOptions={({route, navigation}) => ({
        tabBarActiveTintColor: Colors.primaryDark,
        tabBarInactiveTintColor: Colors.darkGray,
        tabBarStyle: {
          backgroundColor: Colors.primaryLight,
          borderTopWidth: 0,
          height: 60,
          paddingTop: 5,
          paddingBottom: 10,
        },
        headerStyle: {
          backgroundColor: Colors.primaryLight,
          elevation: 0,
          shadowOpacity: 0,
          borderBottomWidth: 0,
        },
        headerTitleStyle: {
          color: Colors.primaryDark,
          fontWeight: 'bold',
        },
        headerLeft: () => (
          <Text style={styles.logo}>Bridge-iT</Text>
        ),
        headerRight: () => (
          <TouchableOpacity
            onPress={() => {
              auth.signOut();
              // Navigation will be handled by the auth state listener
            }}
          >
            <Text style={styles.logout}>Log out</Text>
          </TouchableOpacity>
        ),
      })}
    >
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <View style={styles.tabIconContainer}>
              <Text style={[styles.tabIcon, { color }]}>🏠</Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Bridge-Learning"
        component={LearningScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <View style={styles.tabIconContainer}>
              <Text style={[styles.tabIcon, { color }]}>📚</Text>
            </View>
          ),
        }}
      />
      <Tab.Screen
        name="Profile"
        component={ProfileScreen}
        options={{
          tabBarIcon: ({ color }) => (
            <View style={styles.tabIconContainer}>
              <Text style={[styles.tabIcon, { color }]}>👤</Text>
            </View>
          ),
        }}
      />
    </Tab.Navigator>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [initializing, setInitializing] = useState(true);

  // Handle user state changes
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
      if (initializing) setInitializing(false);
    });

    // Cleanup subscription
    return unsubscribe;
  }, [initializing]);

  if (initializing) {
    return (
      <View style={styles.loadingContainer}>
        <Text style={styles.loadingText}>Loading Bridge-iT...</Text>
      </View>
    );
  }

  return (
    <SafeAreaProvider>
      <PaperProvider>
        <NavigationContainer>
          <StatusBar style="dark" />
          <Stack.Navigator
            screenOptions={{
              headerShown: false,
              cardStyle: { backgroundColor: Colors.primaryLight }
            }}
          >
            {!user ? (
              // Auth screens
              <>
                <Stack.Screen name="Login" component={LoginScreen} />
                <Stack.Screen name="SignUp" component={SignUpScreen} />
                <Stack.Screen name="UserType" component={UserTypeScreen} />
                <Stack.Screen name="Questionnaire" component={QuestionnaireScreen} />
              </>
            ) : (
              // Main app screens
              <>
                <Stack.Screen name="MainTabs" component={BottomTabs} />
                <Stack.Screen
                  name="ViewProfile"
                  component={ViewProfileScreen}
                  options={{
                    headerShown: true,
                    title: 'View Profile',
                    headerStyle: {
                      backgroundColor: Colors.primaryLight,
                    },
                    headerTintColor: Colors.primaryDark,
                  }}
                />
                <Stack.Screen
                  name="Chat"
                  component={ChatScreen}
                  options={{
                    headerShown: true,
                    title: 'Chat',
                    headerStyle: {
                      backgroundColor: Colors.primaryLight,
                    },
                    headerTintColor: Colors.primaryDark,
                  }}
                />
              </>
            )}
          </Stack.Navigator>
        </NavigationContainer>
      </PaperProvider>
    </SafeAreaProvider>
  );
}

const styles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: Colors.primaryLight,
  },
  loadingText: {
    fontSize: 18,
    fontWeight: 'bold',
    color: Colors.primaryDark,
  },
  tabIconContainer: {
    alignItems: 'center',
    justifyContent: 'center',
  },
  tabIcon: {
    fontSize: 22,
  },
  logo: {
    fontWeight: 'bold',
    fontSize: 20,
    color: Colors.primaryDark,
    marginLeft: 15,
  },
  logout: {
    fontSize: 16,
    color: Colors.primaryDark,
    marginRight: 15,
  },
});
