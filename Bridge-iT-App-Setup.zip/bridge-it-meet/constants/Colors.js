// Color constants for the app
const Colors = {
  // Main colors from the provided palette
  primaryGreen: '#92B48D',
  primaryLight: '#BBBEA0',
  primaryDark: '#4A593F',

  // Additional colors for UI elements
  white: '#FFFFFF',
  black: '#000000',
  lightGray: '#EFEFEF',
  mediumGray: '#CCCCCC',
  darkGray: '#666666',
  error: '#FF3B30',
  success: '#34C759',

  // Theme-specific colors
  light: {
    background: '#FFFFFF',
    card: '#BBBEA0',
    text: '#4A593F',
    border: '#92B48D',
    tint: '#92B48D',
    tabIconDefault: '#CCCCCC',
    tabIconSelected: '#4A593F',
  },
  dark: {
    background: '#1E1E1E',
    card: '#2C2C2C',
    text: '#BBBEA0',
    border: '#92B48D',
    tint: '#92B48D',
    tabIconDefault: '#CCCCCC',
    tabIconSelected: '#BBBEA0',
  },
};

export default Colors;
